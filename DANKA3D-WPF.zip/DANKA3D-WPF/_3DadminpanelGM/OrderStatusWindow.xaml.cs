﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using _3DadminpanelGM.Models;
using Microsoft.EntityFrameworkCore;

namespace _3DadminpanelGM
{
    public partial class OrderStatusWindow : Window
    {
        private readonly DatabaseContext context;

        public ObservableCollection<OrderProductModel> OrderProducts { get; set; } = new ObservableCollection<OrderProductModel>();
        public List<string> StatusList { get; set; } = new List<string> { "Elküldve", "Készül", "Összecsomagolva", "Törölve" };
        public OrderModel SelectedOrder { get; private set; }

        public OrderStatusWindow(OrderModel selectedOrder, DatabaseContext dbContext)
        {
            InitializeComponent();
            context = dbContext;
            SelectedOrder = selectedOrder;

            // Betöltjük az adatokat
            context.orderproducts.Include(op => op.Product).Load();
            OrderProducts = new ObservableCollection<OrderProductModel>(
                context.orderproducts.Where(op => op.OrderId == selectedOrder.Id).ToList()
            );

            // Adatforrás beállítása
            DataContext = this;
        }

        private void Mentes_Click(object sender, RoutedEventArgs e)
        {
            // Ellenőrizzük, hogy a státusz kiválasztva van-e
            if (statuszBox.SelectedItem is string newStatus)
            {
                SelectedOrder.Status = newStatus;

                // Mentés az adatbázisba
                var orderInDb = context.orders.SingleOrDefault(o => o.Id == SelectedOrder.Id);
                if (orderInDb != null)
                {
                    orderInDb.Status = SelectedOrder.Status;
                    context.SaveChanges();
                }

                DialogResult = true;
                Close();
            }
        }
    }
}
