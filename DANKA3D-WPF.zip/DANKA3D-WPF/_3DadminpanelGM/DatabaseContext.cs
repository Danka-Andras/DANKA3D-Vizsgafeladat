﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _3DadminpanelGM.Models;
using Microsoft.EntityFrameworkCore;

namespace _3DadminpanelGM
{
    public class DatabaseContext : DbContext
    {
        public DbSet<CartItemModel> cartitems { get; set; }
        public DbSet<CartModel> carts { get; set; }
        public DbSet<OrderModel> orders { get; set; }
        public DbSet<OrderProductModel> orderproducts { get; set; }
        public DbSet<ProductModel> products { get; set; }
        public DbSet<UserModel> users { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("Server=localhost;Database=danka3d;Uid=root;Pwd=;", ServerVersion.AutoDetect("Server=localhost;Database=danka3d;Uid=root;Pwd=;"));
        }
    }
}
