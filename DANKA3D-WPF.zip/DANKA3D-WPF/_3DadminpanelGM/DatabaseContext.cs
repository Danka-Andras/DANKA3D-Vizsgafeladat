﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _3DadminpanelGM.Models;
using Microsoft.EntityFrameworkCore;

namespace _3DadminpanelGM
{
    public class DatabaseContext : DbContext
    {
        public DbSet<CartItemModel> CartItems { get; set; }
        public DbSet<CartModel> Carts { get; set; }
        public DbSet<OrderModel> Orders { get; set; }
        public DbSet<OrderProducts> OrderProducts { get; set; }
        public DbSet<ProductModel> Products { get; set; }
        public DbSet<UserModel> Users { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("Server=localhost;Database=danka3d;Uid=root;Pwd=;", ServerVersion.AutoDetect("Server=localhost;Database=danka3d;Uid=root;Pwd=;"));
        }
    }
}
