﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using _3DadminpanelGM.Models;

namespace _3DadminpanelGM
{
    public partial class ProductsWindow : Window
    {
        private List<ProductModel> _products = new List<ProductModel>();

        public ProductsWindow()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {

        }

        private void UjTermek_Click(object sender, RoutedEventArgs e)
        {
            AddProductWindow addWindow = new AddProductWindow();
            bool? result = addWindow.ShowDialog();

            if (result == true && addWindow.NewProduct != null)
            {
                addWindow.NewProduct.Id = GetNextProductId();
                _products.Add(addWindow.NewProduct);
                ProductsDataGrid.Items.Refresh();
            }
        }

        private int GetNextProductId()
        {
            if (_products.Count == 0)
                return 1;
            return _products[^1].Id + 1;
        }
    }
}
