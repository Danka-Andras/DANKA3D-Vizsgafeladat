﻿using System.Collections.Generic;
using System.Windows;
using System.Linq;
using _3DadminpanelGM.Models;
using Microsoft.EntityFrameworkCore;

namespace _3DadminpanelGM
{
    public partial class ProductsWindow : Window
    {
        private DatabaseContext context;
        private List<ProductModel> _products = new List<ProductModel>();

        public ProductsWindow()
        {
            InitializeComponent();

            // Inicializáljuk az adatbázis kapcsolatot
            context = new DatabaseContext();

            // Betöltjük a termékeket az adatbázisból
            LoadProducts();

            // A DataGrid adatforrásának beállítása
            ProductsDataGrid.ItemsSource = _products;
        }

        private void LoadProducts()
        {
            // Termékek betöltése az adatbázisból
            _products = context.products.ToList();
        }

        private void UjTermek_Click(object sender, RoutedEventArgs e)
        {
            AddProductWindow addWindow = new AddProductWindow();
            bool? result = addWindow.ShowDialog();

            if (result == true && addWindow.NewProduct != null)
            {
                // Új termék hozzáadása az adatbázishoz
                context.products.Add(addWindow.NewProduct);
                context.SaveChanges();

                // Frissítsük az adatforrást és a DataGridet
                LoadProducts();
                ProductsDataGrid.ItemsSource = _products;
            }
        }
    }
}
