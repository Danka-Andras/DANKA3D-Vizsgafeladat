﻿using System.Collections.ObjectModel;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using _3DadminpanelGM.Models;
using Microsoft.EntityFrameworkCore;

namespace _3DadminpanelGM
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler? PropertyChanged;

        private ObservableCollection<UserModel> users = new ObservableCollection<UserModel>();
        public ObservableCollection<UserModel> Users
        {
            get => users;
            set
            {
                users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        private ObservableCollection<OrderModel> orders = new ObservableCollection<OrderModel>();
        public ObservableCollection<OrderModel> Orders
        {
            get => orders;
            set
            {
                orders = value;
                OnPropertyChanged(nameof(Orders));
            }
        }

        private OrderModel selectedOrder;
        public OrderModel SelectedOrder
        {
            get { return selectedOrder; }
            set { selectedOrder = value; OnPropertyChanged(nameof(SelectedOrder)); }
        }


        private DatabaseContext context = new DatabaseContext();
        //private List<OrderProductModel> _products = new List<OrderProductModel>();

        public MainWindow()
        {
            InitializeComponent();
            context.users.Load();
            context.orders.Load();
            //context.OrderProducts.Load();
            Users = context.users.Local.ToObservableCollection();
            Orders = context.orders.Local.ToObservableCollection();
            this.DataContext = this;

        }
        private void SzerkesztStatusz_Click(object sender, RoutedEventArgs e)
        {
            // Ellenőrizze, hogy a gombhoz tartozik egy rendelés
            if (sender is Button button && button.DataContext is OrderModel selectedOrder)
            {
                // Létrehozzuk az OrderStatusWindow ablakot, és átadjuk a kiválasztott rendelést
                OrderStatusWindow statusWindow = new OrderStatusWindow(selectedOrder, context);

                // Az ablak megjelenítése
                bool? result = statusWindow.ShowDialog();

                // Ha a felhasználó mentette a módosítást
                if (result == true)
                {
                    // Frissítjük az adatokat a SelectedOrder alapján
                    OrdersDataGrid.Items.Refresh();
                }
            }
        }


        private void TermekekGomb_Click(object sender, RoutedEventArgs e)
        {
            ProductsWindow productsWindow = new ProductsWindow();
            productsWindow.Owner = this;
            productsWindow.ShowDialog();
        }
    }
}