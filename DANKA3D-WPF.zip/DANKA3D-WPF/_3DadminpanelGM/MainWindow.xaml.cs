﻿using System.Collections.ObjectModel;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using _3DadminpanelGM.Models;

namespace _3DadminpanelGM
{
    public partial class MainWindow : Window
    {
        private List<UserModel> _users = new List<UserModel>();
        private List<OrderModel> _orders = new List<OrderModel>();

        public MainWindow()
        {
            InitializeComponent();
            LoadUsers();
            LoadOrders();
        }

        private void LoadUsers()
        {

        }

        private void LoadOrders()
        {

        }

        private void SzerkesztStatusz_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is OrderModel selectedOrder)
            {
                OrderStatusWindow statusWindow = new OrderStatusWindow(selectedOrder.Status ?? "");
                bool? result = statusWindow.ShowDialog();

                if (result == true && statusWindow.SelectedStatus != null)
                {
                    selectedOrder.Status = statusWindow.SelectedStatus;
                    OrdersDataGrid.Items.Refresh();
                }
            }
        }



        private void TermekekGomb_Click(object sender, RoutedEventArgs e)
        {
            ProductsWindow productsWindow = new ProductsWindow();
            productsWindow.Owner = this;
            productsWindow.ShowDialog();
        }
    }
}