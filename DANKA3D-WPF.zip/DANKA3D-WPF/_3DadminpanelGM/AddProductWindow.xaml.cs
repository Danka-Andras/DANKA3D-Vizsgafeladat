﻿using System;
using System.Windows;
using _3DadminpanelGM.Models;

namespace _3DadminpanelGM
{
    public partial class AddProductWindow : Window
    {
        public ProductModel? NewProduct { get; private set; }

        public AddProductWindow()
        {
            InitializeComponent();
        }

        private void Mentes_Click(object sender, RoutedEventArgs e)
        {
            // Ellenőrizzük a szükséges mezőket
            if (!ValidateInputs())
            {
                MessageBox.Show("Kérlek töltsd ki a kötelező mezőket helyesen!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Létrehozzuk az új terméket
            NewProduct = new ProductModel
            {
                Id = 0, // Az adatbázisban automatikusan kerül generálásra
                Name = NameBox.Text.Trim(),
                Description = string.IsNullOrWhiteSpace(DescriptionBox.Text) ? null : DescriptionBox.Text.Trim(),
                Price = decimal.Parse(PriceBox.Text.Trim()),            
                Color = string.IsNullOrWhiteSpace(ColorBox.Text) ? null : ColorBox.Text.Trim(),
                ImageUrl = string.IsNullOrWhiteSpace(ImageUrlBox.Text) ? null : ImageUrlBox.Text.Trim(),
                CreatedAt = DateTime.Now
            };

            this.DialogResult = true;
            this.Close();
        }

        private bool ValidateInputs()
        {
            // Ellenőrzés: A mezők nem lehetnek üresek, és az értékeknek érvényesnek kell lenniük
            return
                !string.IsNullOrWhiteSpace(NameBox.Text) &&
                !string.IsNullOrWhiteSpace(PriceBox.Text) && decimal.TryParse(PriceBox.Text, out _);

        }
    }
}
