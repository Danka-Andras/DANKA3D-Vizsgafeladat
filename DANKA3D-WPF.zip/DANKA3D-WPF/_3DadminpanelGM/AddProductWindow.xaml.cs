﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using _3DadminpanelGM.Models;

namespace _3DadminpanelGM
{
    public partial class AddProductWindow : Window
    {
        public ProductModel? NewProduct { get; private set; }

        public AddProductWindow()
        {
            InitializeComponent();
        }

        private void Mentes_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text) || string.IsNullOrWhiteSpace(PriceBox.Text) || string.IsNullOrWhiteSpace(StockBox.Text))
            {
                MessageBox.Show("Kérlek töltsd ki a kötelező mezőket!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            NewProduct = new ProductModel
            {
                Id = 0, // ezt majd automatikusan állíthatod ha adatbázishoz kötöd
                Name = NameBox.Text,
                Description = DescriptionBox.Text,
                Price = decimal.TryParse(PriceBox.Text, out var price) ? price : 0,
                Stock = int.TryParse(StockBox.Text, out var stock) ? stock : 0,
                Color = ColorBox.Text,
                ImageUrl = ImageUrlBox.Text,
                CreatedAt = DateTime.Now
            };

            this.DialogResult = true;
            this.Close();
        }
    }
}
